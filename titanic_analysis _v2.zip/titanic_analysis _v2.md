

```python
import unicodecsv
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

%matplotlib inline
```


```python
import unicodecsv
def read_csv(file_name):
    with open(file_name, 'rb') as f:
        reader = unicodecsv.DictReader(f)
        return list(reader)
titanic_data = read_csv('titanic_data.csv')
print titanic_data[0]
```

    {u'Fare': u'7.25', u'Name': u'Braund, Mr. Owen Harris', u'Embarked': u'S', u'Age': u'22', u'Parch': u'0', u'Pclass': u'3', u'Sex': u'male', u'Survived': u'0', u'SibSp': u'1', u'PassengerId': u'1', u'Ticket': u'A/5 21171', u'Cabin': u''}
    


```python
#adj data type 
# Age lost
# Cabin lost
def parse_maybe_float(i):
    if i == '':
        return None
    else:
        return float(i)
    
def parse_maybe_str(i):
    if i == '':
        return None
    else:
        return str(i)
    
for titanic_data_item in titanic_data:
    titanic_data_item['Age'] = parse_maybe_float(titanic_data_item['Age'])
    titanic_data_item['Cabin'] = parse_maybe_str(titanic_data_item['Cabin'])
titanic_data[0]
```




    {u'Age': 22.0,
     u'Cabin': None,
     u'Embarked': u'S',
     u'Fare': u'7.25',
     u'Name': u'Braund, Mr. Owen Harris',
     u'Parch': u'0',
     u'PassengerId': u'1',
     u'Pclass': u'3',
     u'Sex': u'male',
     u'SibSp': u'1',
     u'Survived': u'0',
     u'Ticket': u'A/5 21171'}




```python
len(titanic_data)
```




    891




```python
titanic_df=pd.read_csv('titanic_data.csv')
```


```python
titanic_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>PassengerId</th>
      <th>Survived</th>
      <th>Pclass</th>
      <th>Name</th>
      <th>Sex</th>
      <th>Age</th>
      <th>SibSp</th>
      <th>Parch</th>
      <th>Ticket</th>
      <th>Fare</th>
      <th>Cabin</th>
      <th>Embarked</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>Braund, Mr. Owen Harris</td>
      <td>male</td>
      <td>22.0</td>
      <td>1</td>
      <td>0</td>
      <td>A/5 21171</td>
      <td>7.2500</td>
      <td>NaN</td>
      <td>S</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>Cumings, Mrs. John Bradley (Florence Briggs Th...</td>
      <td>female</td>
      <td>38.0</td>
      <td>1</td>
      <td>0</td>
      <td>PC 17599</td>
      <td>71.2833</td>
      <td>C85</td>
      <td>C</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>1</td>
      <td>3</td>
      <td>Heikkinen, Miss. Laina</td>
      <td>female</td>
      <td>26.0</td>
      <td>0</td>
      <td>0</td>
      <td>STON/O2. 3101282</td>
      <td>7.9250</td>
      <td>NaN</td>
      <td>S</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>1</td>
      <td>1</td>
      <td>Futrelle, Mrs. Jacques Heath (Lily May Peel)</td>
      <td>female</td>
      <td>35.0</td>
      <td>1</td>
      <td>0</td>
      <td>113803</td>
      <td>53.1000</td>
      <td>C123</td>
      <td>S</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>0</td>
      <td>3</td>
      <td>Allen, Mr. William Henry</td>
      <td>male</td>
      <td>35.0</td>
      <td>0</td>
      <td>0</td>
      <td>373450</td>
      <td>8.0500</td>
      <td>NaN</td>
      <td>S</td>
    </tr>
  </tbody>
</table>
</div>




```python
titanic_df.info()
#Age Cabin Embarked lost some  data
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 891 entries, 0 to 890
    Data columns (total 12 columns):
    PassengerId    891 non-null int64
    Survived       891 non-null int64
    Pclass         891 non-null int64
    Name           891 non-null object
    Sex            891 non-null object
    Age            714 non-null float64
    SibSp          891 non-null int64
    Parch          891 non-null int64
    Ticket         891 non-null object
    Fare           891 non-null float64
    Cabin          204 non-null object
    Embarked       889 non-null object
    dtypes: float64(2), int64(5), object(5)
    memory usage: 66.2+ KB
    


```python
titanic_df.describe()
#Survived% is only 38.38%
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>PassengerId</th>
      <th>Survived</th>
      <th>Pclass</th>
      <th>Age</th>
      <th>SibSp</th>
      <th>Parch</th>
      <th>Fare</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>891.000000</td>
      <td>891.000000</td>
      <td>891.000000</td>
      <td>714.000000</td>
      <td>891.000000</td>
      <td>891.000000</td>
      <td>891.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>446.000000</td>
      <td>0.383838</td>
      <td>2.308642</td>
      <td>29.699118</td>
      <td>0.523008</td>
      <td>0.381594</td>
      <td>32.204208</td>
    </tr>
    <tr>
      <th>std</th>
      <td>257.353842</td>
      <td>0.486592</td>
      <td>0.836071</td>
      <td>14.526497</td>
      <td>1.102743</td>
      <td>0.806057</td>
      <td>49.693429</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.420000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>223.500000</td>
      <td>0.000000</td>
      <td>2.000000</td>
      <td>20.125000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>7.910400</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>446.000000</td>
      <td>0.000000</td>
      <td>3.000000</td>
      <td>28.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>14.454200</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>668.500000</td>
      <td>1.000000</td>
      <td>3.000000</td>
      <td>38.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>31.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>891.000000</td>
      <td>1.000000</td>
      <td>3.000000</td>
      <td>80.000000</td>
      <td>8.000000</td>
      <td>6.000000</td>
      <td>512.329200</td>
    </tr>
  </tbody>
</table>
</div>




```python
#count the survived and no survived Passenger
num_survived = titanic_df['Survived'].sum()
num_no_survived = 891 - num_survived

print num_survived
print num_no_survived
```

    342
    549
    


```python
#draw a Figure  to show Survived and Victim
plt.figure(figsize = (12,6))
plt.subplot(121)
sns.countplot(x='Survived', data=titanic_df)
plt.title('Survived person count')

plt.subplot(122)
plt.pie([num_survived, num_no_survived],labels=['Survived','Victim'],autopct='%1.0f%%')
plt.title('Survived persontage') 

plt.show()
```


![png](output_9_0.png)



```python
#according to the film, I prefer to check the persentage of female survived 
#step 1  I should check how many people on Titanic before wrecked
male_sum = titanic_df['Sex'][titanic_df['Sex'] == 'male'].count()
female_sum = titanic_df['Sex'][titanic_df['Sex'] == 'female'].count()
print male_sum
print female_sum
```

    577
    314
    


```python
plt.figure(figsize=(12,6))
plt.subplot(121)
sns.countplot(x='Sex', data=titanic_df)
plt.subplot(122)
plt.pie([male_sum,female_sum],labels=['male', 'female'],autopct='%1.0f%%')
plt.show()
#there are 577 male, and 314 female before wrecked
```


![png](output_11_0.png)



```python
#after the Titanic wreck
survived_df = titanic_df[titanic_df[ 'Survived'] == 1 ]
```


```python
# check the Survived of male and female
survived_male_sum = survived_df['Sex'][survived_df['Sex'] == 'male'].count()
survived_female_sum = survived_df['Sex'][survived_df['Sex'] == 'female'].count()
print survived_male_sum 
print survived_female_sum
```

    109
    233
    


```python
plt.figure(figsize=(10,5))
plt.subplot(121)
sns.countplot(x='Sex', data=survived_df)
plt.subplot(122)
plt.pie([survived_male_sum, survived_female_sum],labels=['survived male', 'survived female'],autopct='%1.0f%%')
plt.show()
#the survived female 109 is more than male 233,
```


![png](output_14_0.png)



```python
#Survived persentage of male
male_df = titanic_df[titanic_df['Sex'] == 'male']

plt.figure(figsize=(10,5))
plt.subplot(121)
sns.countplot(x = 'Survived', data = male_df)
plt.subplot(122)
plt.pie([male_df['Survived'][male_df['Survived'] == 0].count(),male_df['Survived'][male_df['Survived'] == 1].count()],labels=['Male Victim', 'Survived male'],autopct='%1.0f%%')
plt.show()
```


![png](output_15_0.png)



```python
#Survived persentage of female
female_df = titanic_df[titanic_df['Sex'] == 'female']

plt.figure(figsize=(10,5))
plt.subplot(121)
sns.countplot(x = 'Survived', data = female_df)
plt.subplot(122)
plt.pie([female_df['Survived'][female_df['Survived'] == 0].count(),female_df['Survived'][female_df['Survived'] == 1].count()],labels=['Victim female', 'Survived female'],autopct='%1.0f%%')
plt.show()

 #the survived female 74% percentage is higher than male 19%， Titanic film tells us the true,from the result above.
```


![png](output_16_0.png)



```python
# Secondly,I prefre to check the Survived age. as the Titanic Film.
# I found the some of the age data is lost; we need to fill in  the lost age of data.
avg_age_titanic   = titanic_df["Age"].mean()
std_age_titanic   = titanic_df["Age"].std()
count_nan_age_titanic = titanic_df["Age"].isnull().sum()

# random age，range (mean - std， mean + std)
rand_age = np.random.randint(avg_age_titanic - std_age_titanic, avg_age_titanic + std_age_titanic, size = count_nan_age_titanic)

# 将随机数填充进 Age 的丢失值中
titanic_df["Age"][np.isnan(titanic_df["Age"])] = rand_age
```

    D:\Anaconda\lib\site-packages\ipykernel_launcher.py:11: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      # This is added back by InteractiveShellApp.init_path()
    


```python
plt.figure(figsize=(12,5))
plt.subplot(121)
titanic_df['Age'].hist(bins = 70)
plt.xlabel('Age')
plt.ylabel('Num')
#acccording to the hist, I found the age data Concentrated in the peak age between 20-40 years of age，the boxplot may show the result  visually。
plt.subplot(122)
titanic_df.boxplot(column='Age', showfliers=False)

plt.show()
```


![png](output_18_0.png)



```python
titanic_df['Age'].describe()
# According to the sample,total 891, the avg is  29.59, std  13.54,the youngest is 0.42, the eldest is 80.
```




    count    891.000000
    mean      29.703895
    std       13.522854
    min        0.420000
    25%       21.000000
    50%       29.000000
    75%       38.000000
    max       80.000000
    Name: Age, dtype: float64




```python
# before analysis the age result,I group the age data to children,Teenagers，adult，and elderly people 4 groups。
bins = [0, 12, 18, 65, 100]
titanic_df['Age_group'] = pd.cut(titanic_df['Age'], bins)
by_age = titanic_df.groupby('Age_group')['Survived'].mean()
by_age
```




    Age_group
    (0, 12]      0.579710
    (12, 18]     0.404255
    (18, 65]     0.365278
    (65, 100]    0.125000
    Name: Survived, dtype: float64




```python
by_age.plot(kind = "bar")
#the Survived persontage of children is higher than juvenile and adult, the agedness is lowest.
```




    <matplotlib.axes._subplots.AxesSubplot at 0xb5dd830>




![png](output_21_1.png)



```python
#Survived persentage by different Pclass
titanic_df[['Pclass','Survived']].groupby(['Pclass']).count()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Survived</th>
    </tr>
    <tr>
      <th>Pclass</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>216</td>
    </tr>
    <tr>
      <th>2</th>
      <td>184</td>
    </tr>
    <tr>
      <th>3</th>
      <td>491</td>
    </tr>
  </tbody>
</table>
</div>




```python
#analysis data from the Pclass before the Ship wreck
plt.figure(figsize= (10 ,5))
plt.subplot(121)
sns.countplot(x='Pclass', data=titanic_df)
plt.title('Pclass Count') 

plt.subplot(122)
plt.pie(titanic_df[['Pclass','Survived']].groupby(['Pclass']).count(),labels=['Pclass_1','Pclass_2','Pclass_3'],autopct='%1.0f%%')

plt.show()

```


![png](output_23_0.png)



```python
survived_df[['Pclass','Survived']].groupby(['Pclass']).sum()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Survived</th>
    </tr>
    <tr>
      <th>Pclass</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>136</td>
    </tr>
    <tr>
      <th>2</th>
      <td>87</td>
    </tr>
    <tr>
      <th>3</th>
      <td>119</td>
    </tr>
  </tbody>
</table>
</div>




```python
#analysis data from the Pclass before the Ship wreck
plt.figure(figsize= (10, 5))
plt.subplot(121)
sns.countplot(x='Pclass', data=survived_df)
plt.title('Survived by Pclass') 
plt.ylabel('Survived Count')

plt.subplot(122)
plt.pie(survived_df[['Pclass','Survived']].groupby(['Pclass']).sum(),labels=['Pclass_1','Pclass_2','Pclass_3'],autopct='%1.0f%%')
plt.show()
```


![png](output_25_0.png)



```python
bins = [0 ,1, 2, 3]
titanic_df['Pclass_group'] = pd.cut(titanic_df['Pclass'], bins)
by_Pclass = titanic_df.groupby('Pclass_group')['Survived'].mean()
by_Pclass
# the percentage and count of Survived from Pclass_1 is highest
```




    Pclass_group
    (0, 1]    0.629630
    (1, 2]    0.472826
    (2, 3]    0.242363
    Name: Survived, dtype: float64




```python
by_Pclass.plot(kind = "bar")
```




    <matplotlib.axes._subplots.AxesSubplot at 0x9d64e10>




![png](output_27_1.png)



```python
#Survived by Fare
plt.figure(figsize=(10,5))
titanic_df['Fare'].hist(bins = 50)

titanic_df.boxplot(column='Fare', by='Survived', showfliers=False)
plt.show()
#the Survived Passenger in higher Fare is higher than lower Fare
```


![png](output_28_0.png)



![png](output_28_1.png)



```python
#check the data lost Embarked
num_lost_Embarked = 0
for titanic_data_item in titanic_data:

    if(titanic_data_item['Embarked']==''):
        print titanic_data_item
        num_lost_Embarked += 1

num_lost_Embarked
```

    {u'Fare': u'80', u'Name': u'Icard, Miss. Amelie', u'Embarked': u'', u'Age': 38.0, u'Parch': u'0', u'Pclass': u'1', u'Sex': u'female', u'Survived': u'1', u'SibSp': u'0', u'PassengerId': u'62', u'Ticket': u'113572', u'Cabin': 'B28'}
    {u'Fare': u'80', u'Name': u'Stone, Mrs. George Nelson (Martha Evelyn)', u'Embarked': u'', u'Age': 62.0, u'Parch': u'0', u'Pclass': u'1', u'Sex': u'female', u'Survived': u'1', u'SibSp': u'0', u'PassengerId': u'830', u'Ticket': u'113572', u'Cabin': 'B28'}
    




    2




```python
#lost the Embarked of 2 and  u'Ticket is all 113572,the others 1135**'s Embarked is S，and mode is also S
titanic_df["Embarked"] = titanic_df["Embarked"].fillna("S")
```


```python
fig, (axis1,axis2,axis3) = plt.subplots(1,3,figsize=(15,5)) 

sns.countplot(x='Embarked', data=titanic_df, ax=axis1)
embark_perc = titanic_df[["Embarked", "Survived"]].groupby(['Embarked'],as_index=False).mean()
sns.barplot(x='Embarked', y='Survived', data=embark_perc,order=['S','C','Q'],ax=axis2)
sns.countplot(x='Survived', hue="Embarked", data=titanic_df, order=[1,0], ax=axis3)

#Survived passager in Embarked S is largest，EmbarkedS Q is Minimum。Survived percentage in Embarked C is highest and S is lowest。
```




    <matplotlib.axes._subplots.AxesSubplot at 0xbb3afd0>




![png](output_31_1.png)



```python
# Survived by have sibling or not
sibsp_df = titanic_df[titanic_df['SibSp'] != 0]
no_sibsp_df = titanic_df[titanic_df['SibSp'] == 0]
```


```python
#the psassageer
plt.figure(figsize=(10,5))
plt.subplot(121)
sns.countplot(x = 'Survived', data = sibsp_df )

plt.subplot(122)
plt.pie([sibsp_df['Survived'][sibsp_df['Survived'] == 0].count(),sibsp_df['Survived'].sum()],labels=['Victim', 'Survived'],autopct='%1.0f%%')
plt.show()
print sibsp_df['Survived'][sibsp_df['Survived'] == 0].count(), sibsp_df['Survived'].sum()
#the count of survived passagers have siblings is 132, survived percentage is 47%,higher than the average 38%
```


![png](output_33_0.png)


    151 132
    


```python
plt.figure(figsize=(10,5))
plt.subplot(121)
sns.countplot(x = 'Survived', data = no_sibsp_df )

plt.subplot(122)
plt.pie([no_sibsp_df['Survived'][no_sibsp_df['Survived'] == 0].count(),no_sibsp_df['Survived'].sum()],labels=['Victim', 'Survived'],autopct='%1.0f%%')
plt.show()
print no_sibsp_df['Survived'][no_sibsp_df['Survived'] == 0].count(), no_sibsp_df['Survived'].sum()
#the count of Survived passsage have no siblings is 210, percentage is 35%,lower than the passsage have siblings.
```


![png](output_34_0.png)


    398 210
    


```python
# Survived by Parch
parch_df = titanic_df[titanic_df['Parch'] != 0]
no_parch_df = titanic_df[titanic_df['Parch'] == 0]
```


```python
plt.figure(figsize=(10,5))
plt.subplot(121)
sns.countplot(x = 'Survived', data = parch_df )

plt.subplot(122)
plt.pie([parch_df['Survived'][parch_df['Survived'] == 0].count(),parch_df['Survived'].sum()],labels=['Victim', 'Survived'],autopct='%1.0f%%')
plt.show()
print parch_df['Survived'][parch_df['Survived'] == 0].count(),parch_df['Survived'].sum()
#the count of survived passagers have parent is 109, and the survived percentage is 51%
```


![png](output_36_0.png)


    104 109
    


```python
plt.figure(figsize=(10,5))
plt.subplot(121)
sns.countplot(x = 'Survived', data = no_parch_df)

plt.subplot(122)
plt.pie([no_parch_df['Survived'][no_parch_df['Survived'] == 0].count(),no_parch_df['Survived'].sum()],labels=['Victim', 'Survived'],autopct='%1.0f%%')
plt.show()
print no_parch_df['Survived'][no_parch_df['Survived'] == 0].count(),no_parch_df['Survived'].sum()
#the count of survived passagers have no parent is 233, and the survived percentage is 34%
#the survived percentage of passengers have parent together is highter than passengers have no parent together 
```


![png](output_37_0.png)


    445 233
    


```python
data_by_location = titanic_df.groupby(['Sex','Age'],as_index=False).mean()
```


```python
data_by_location.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Sex</th>
      <th>Age</th>
      <th>PassengerId</th>
      <th>Survived</th>
      <th>Pclass</th>
      <th>SibSp</th>
      <th>Parch</th>
      <th>Fare</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>female</td>
      <td>0.75</td>
      <td>557.500000</td>
      <td>1.000000</td>
      <td>3.0</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>19.258300</td>
    </tr>
    <tr>
      <th>1</th>
      <td>female</td>
      <td>1.00</td>
      <td>277.500000</td>
      <td>1.000000</td>
      <td>3.0</td>
      <td>0.5</td>
      <td>1.5</td>
      <td>13.437500</td>
    </tr>
    <tr>
      <th>2</th>
      <td>female</td>
      <td>2.00</td>
      <td>379.666667</td>
      <td>0.333333</td>
      <td>2.5</td>
      <td>1.5</td>
      <td>1.5</td>
      <td>43.245833</td>
    </tr>
    <tr>
      <th>3</th>
      <td>female</td>
      <td>3.00</td>
      <td>209.500000</td>
      <td>0.500000</td>
      <td>2.5</td>
      <td>2.0</td>
      <td>1.5</td>
      <td>31.327100</td>
    </tr>
    <tr>
      <th>4</th>
      <td>female</td>
      <td>4.00</td>
      <td>451.600000</td>
      <td>1.000000</td>
      <td>2.6</td>
      <td>0.8</td>
      <td>1.2</td>
      <td>22.828340</td>
    </tr>
  </tbody>
</table>
</div>




```python
data_by_location.head()['Age']
```




    0    0.75
    1    1.00
    2    2.00
    3    3.00
    4    4.00
    Name: Age, dtype: float64




```python
%pylab inline
import matplotlib.pyplot as plt
import seaborn as sns
```

    Populating the interactive namespace from numpy and matplotlib
    


```python
scaled_entries_1 = (data_by_location['Survived']/data_by_location['Survived'].std())
```


```python
plt.scatter(data_by_location['Sex'],data_by_location['Age'],s=scaled_entries_1)
#female survived percentage is higher than male
```




    <matplotlib.collections.PathCollection at 0xa224350>




![png](output_43_1.png)



```python
data_by_location = titanic_df.groupby(['Pclass','Age'],as_index=False).mean()
```


```python
data_by_location.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Pclass</th>
      <th>Age</th>
      <th>PassengerId</th>
      <th>Survived</th>
      <th>SibSp</th>
      <th>Parch</th>
      <th>Fare</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>0.92</td>
      <td>306.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>151.5500</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>2.00</td>
      <td>298.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>151.5500</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>4.00</td>
      <td>446.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>81.8583</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>11.00</td>
      <td>803.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>120.0000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>14.00</td>
      <td>436.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>120.0000</td>
    </tr>
  </tbody>
</table>
</div>




```python
data_by_location.head()['Age']
```




    0     0.92
    1     2.00
    2     4.00
    3    11.00
    4    14.00
    Name: Age, dtype: float64




```python
%pylab inline
import matplotlib.pyplot as plt
import seaborn as sns
```

    Populating the interactive namespace from numpy and matplotlib
    


```python
scaled_entries_2 = (data_by_location['Survived']/data_by_location['Survived'].std())
```


```python
plt.scatter(data_by_location['Pclass'],data_by_location['Age'],s=scaled_entries_2)
```




    <matplotlib.collections.PathCollection at 0xa224c70>




![png](output_49_1.png)


data_by_location = titanic_df.groupby(['Fare','Age'],as_index=False).mean()


```python
data_by_location.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Pclass</th>
      <th>Age</th>
      <th>PassengerId</th>
      <th>Survived</th>
      <th>SibSp</th>
      <th>Parch</th>
      <th>Fare</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>0.92</td>
      <td>306.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>151.5500</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>2.00</td>
      <td>298.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>151.5500</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>4.00</td>
      <td>446.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>81.8583</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>11.00</td>
      <td>803.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>120.0000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>14.00</td>
      <td>436.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>120.0000</td>
    </tr>
  </tbody>
</table>
</div>




```python
data_by_location.head()['Age']
```




    0     0.92
    1     2.00
    2     4.00
    3    11.00
    4    14.00
    Name: Age, dtype: float64




```python
%pylab inline
import matplotlib.pyplot as plt
import seaborn as sns
```

    Populating the interactive namespace from numpy and matplotlib
    


```python
scaled_entries = (data_by_location['Survived']/data_by_location['Survived'].std())
```


```python
plt.scatter(data_by_location['Fare'],data_by_location['Age'],s=scaled_entries)
```




    <matplotlib.collections.PathCollection at 0xa302550>




![png](output_55_1.png)



```python
#通过绘图得知在泰坦尼克船上，获救的人集中在Fare较低（0,50]，年龄集中在10岁以上35岁以下乘客中的几率比较大
```


```python
data_by_location = titanic_df.groupby(['Parch','SibSp'],as_index=False).mean()
```


```python
data_by_location.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Parch</th>
      <th>SibSp</th>
      <th>PassengerId</th>
      <th>Survived</th>
      <th>Pclass</th>
      <th>Age</th>
      <th>Fare</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>0</td>
      <td>458.000000</td>
      <td>0.303538</td>
      <td>2.400372</td>
      <td>31.625698</td>
      <td>21.242689</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>1</td>
      <td>399.609756</td>
      <td>0.520325</td>
      <td>1.959350</td>
      <td>31.536585</td>
      <td>42.610402</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>2</td>
      <td>373.250000</td>
      <td>0.250000</td>
      <td>2.437500</td>
      <td>30.312500</td>
      <td>41.411200</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>3</td>
      <td>406.500000</td>
      <td>1.000000</td>
      <td>2.500000</td>
      <td>31.500000</td>
      <td>18.425000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>0</td>
      <td>455.657895</td>
      <td>0.657895</td>
      <td>1.789474</td>
      <td>29.563684</td>
      <td>73.470400</td>
    </tr>
  </tbody>
</table>
</div>




```python
data_by_location.head()['SibSp']
```




    0    0
    1    1
    2    2
    3    3
    4    0
    Name: SibSp, dtype: int64




```python
%pylab inline
import matplotlib.pyplot as plt
import seaborn as sns
```

    Populating the interactive namespace from numpy and matplotlib
    


```python
plt.scatter(data_by_location['SibSp'],data_by_location['Parch'],s=scaled_entries)
#no parents or siblings passagers survived percentage is lower.
```




    <matplotlib.collections.PathCollection at 0x99aad70>




![png](output_61_1.png)



```python
# inconclusion, the female passenage in  Pclass _1, who have child,siblings parents on ship, age yonger, have higher persentge of Survived
```
